# Ren'Py lexer (Kotlin)

Standalone Kotlin/JVM lexical foundation for a Ren'Py IntelliJ plugin.

Includes physical-line reading, logical-line scanning, indentation grouping,
a small token lexer and JUnit 5 tests. Requires JDK 17+ and Gradle 8+.

Run `gradle test`.

This is a starting implementation, not a complete port of Ren'Py's lexer.
It does not yet implement every Ren'Py lexical mode, embedded Python tokenisation,
screen language, ATL, interpolation or creator-defined statements. The standalone
`RenPyLexer` is not yet an IntelliJ `LexerBase`; adapt it for incremental IntelliJ
lexing after validating the lexical rules against real projects.
