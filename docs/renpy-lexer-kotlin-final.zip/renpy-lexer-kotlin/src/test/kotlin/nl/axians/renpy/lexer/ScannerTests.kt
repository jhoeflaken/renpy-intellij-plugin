package nl.axians.renpy.lexer

import nl.axians.renpy.lexer.model.*
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ScannerTests {
    @Test fun physicalLinesHandleNewlineVariants() {
        val lines = PhysicalLineReader.read("a\r\nb\nc\rd")
        assertEquals(listOf("a", "b", "c", "d"), lines.map { it.text })
        assertEquals(listOf(0, 3, 5, 7), lines.map { it.startOffset })
    }

    @Test fun multilineCallIsOneLogicalLine() {
        val result = RenPyLogicalLineScanner().scan("""define alice = Character(
    "Alice",
    color="#ff0000"
)""")
        assertEquals(1, result.logicalLines.size)
        assertTrue(result.diagnostics.isEmpty())
    }

    @Test fun tripleQuotedStringSpansLines() {
        val result = RenPyLogicalLineScanner().scan("define x = \"\"\"first\nsecond\nthird\"\"\"")
        assertEquals(1, result.logicalLines.size)
        assertTrue(result.logicalLines.single().text.contains("second"))
    }

    @Test fun hashInsideStringIsNotComment() {
        val result = RenPyLogicalLineScanner().scan("""define c = "#ff0000" # comment""")
        assertTrue(result.logicalLines.single().text.contains("#ff0000"))
        assertTrue(!result.logicalLines.single().text.contains("# comment"))
    }

    @Test fun explicitBackslashContinues() {
        val result = RenPyLogicalLineScanner().scan("$ x = 10 + \\\n    20")
        assertEquals(1, result.logicalLines.size)
        assertTrue(result.logicalLines.single().text.contains("20"))
    }

    @Test fun bracketContinuationIgnoresInnerIndent() {
        val result = RenPyLogicalLineScanner().scan("x = (\n        1,\n        2\n    )\nlabel next:")
        assertEquals(listOf(0, 0), result.logicalLines.map { it.indent })
    }

    @Test fun malformedDelimitersAreReported() {
        val result = RenPyLogicalLineScanner().scan("x = (1 + 2")
        assertTrue(result.diagnostics.any { it.code == DiagnosticCode.UNCLOSED_DELIMITER })
        assertTrue(RenPyLogicalLineScanner().scan("x = 1)").diagnostics.any { it.code == DiagnosticCode.UNMATCHED_CLOSING_DELIMITER })
    }

    @Test fun unclosedStringIsReported() {
        val result = RenPyLogicalLineScanner().scan("""x = "unfinished""")
        assertTrue(result.diagnostics.any { it.code == DiagnosticCode.UNCLOSED_STRING })
    }

    @Test fun tabIndentIsReported() {
        val result = RenPyLogicalLineScanner().scan("label start:\n\treturn")
        assertTrue(result.diagnostics.any { it.code == DiagnosticCode.TAB_INDENTATION })
    }

    @Test fun indentationProducesBalancedEvents() {
        val source = """label start:
    if True:
        "Hello"
    return"""
        val scan = RenPyLogicalLineScanner().scan(source)
        val events = RenPyIndentationGrouper().group(scan.logicalLines, scan.sourceLength).events
        assertEquals(
            listOf(IndentationType.INDENT, IndentationType.INDENT, IndentationType.DEDENT, IndentationType.DEDENT),
            events.map { it.type }
        )
    }

    @Test fun inconsistentDedentIsReported() {
        val scan = RenPyLogicalLineScanner().scan("a\n    b\n  c")
        val grouped = RenPyIndentationGrouper().group(scan.logicalLines, scan.sourceLength)
        assertTrue(grouped.diagnostics.any { it.code == DiagnosticCode.INCONSISTENT_INDENTATION })
    }

    @Test fun lexerRecognisesKeywordStringCommentAndIndentation() {
        val tokens = RenPyLexer().lex("label start:\n    return # done\n")
        assertEquals(TokenType.KEYWORD, tokens.first { it.text == "label" }.type)
        assertTrue(tokens.any { it.type == TokenType.STRING })
        assertTrue(tokens.any { it.type == TokenType.COMMENT })
        assertTrue(tokens.any { it.type == TokenType.INDENT })
        assertTrue(tokens.any { it.type == TokenType.DEDENT })
        assertEquals(TokenType.EOF, tokens.last().type)
    }
}
