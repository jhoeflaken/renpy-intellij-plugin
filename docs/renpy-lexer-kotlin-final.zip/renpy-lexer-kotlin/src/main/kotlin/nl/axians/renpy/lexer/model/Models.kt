package nl.axians.renpy.lexer.model

data class TextRange(val startOffset: Int, val endOffset: Int)
data class PhysicalLine(val lineNumber: Int, val startOffset: Int, val contentEndOffset: Int, val endOffset: Int, val text: String)
data class LogicalLine(val startLine: Int, val endLine: Int, val startOffset: Int, val endOffset: Int, val indent: Int, val segments: List<TextRange>, val text: String)

enum class DiagnosticCode {
    UNMATCHED_CLOSING_DELIMITER, UNCLOSED_DELIMITER, UNCLOSED_STRING,
    TAB_INDENTATION, INCONSISTENT_INDENTATION
}
data class LexicalDiagnostic(val code: DiagnosticCode, val message: String, val offset: Int, val line: Int)
data class LogicalScanResult(val logicalLines: List<LogicalLine>, val diagnostics: List<LexicalDiagnostic>, val sourceLength: Int)

enum class IndentationType { INDENT, DEDENT }
data class IndentationEvent(val type: IndentationType, val offset: Int, val line: Int)
data class IndentationResult(val events: List<IndentationEvent>, val diagnostics: List<LexicalDiagnostic>)

enum class TokenType { KEYWORD, IDENTIFIER, NUMBER, STRING, OPERATOR, PUNCTUATION, COMMENT, NEWLINE, INDENT, DEDENT, WHITESPACE, BAD_CHARACTER, EOF }
data class RenPyToken(val type: TokenType, val startOffset: Int, val endOffset: Int, val text: String)
