package nl.axians.renpy.lexer

import nl.axians.renpy.lexer.model.*
import java.util.ArrayDeque

/** Basic standalone tokenizer; adapt to IntelliJ LexerBase for plugin integration. */
class RenPyLexer(private val keywords: Set<String> = DEFAULT_KEYWORDS) {
    fun lex(source: CharSequence): List<RenPyToken> {
        val tokens = mutableListOf<RenPyToken>()
        val indentStack = ArrayDeque<Int>()
        indentStack.addLast(0)
        var i = 0
        var atLineStart = true

        fun add(type: TokenType, start: Int, end: Int) {
            if (end > start) tokens += RenPyToken(type, start, end, source.subSequence(start, end).toString())
        }

        while (i < source.length) {
            var c = source[i]
            if (c == '\r' || c == '\n') {
                val start = i
                if (c == '\r' && i + 1 < source.length && source[i + 1] == '\n') i += 2 else i++
                add(TokenType.NEWLINE, start, i)
                atLineStart = true
                continue
            }
            if (atLineStart) {
                val start = i
                var col = 0
                while (i < source.length && (source[i] == ' ' || source[i] == '\t')) {
                    col = if (source[i] == '\t') (col / 8 + 1) * 8 else col + 1
                    i++
                }
                add(TokenType.WHITESPACE, start, i)
                if (i >= source.length) break
                // Blank and comment-only lines do not change the indentation stack.
                val isBlankOrComment = source[i] == '\r' || source[i] == '\n' || source[i] == '#'
                if (!isBlankOrComment) {
                    while (indentStack.size > 1 && col < indentStack.last()) {
                        indentStack.removeLast()
                        tokens += RenPyToken(TokenType.DEDENT, i, i, "")
                    }
                    if (col > indentStack.last()) {
                        indentStack.addLast(col)
                        tokens += RenPyToken(TokenType.INDENT, i, i, "")
                    }
                }
                atLineStart = false
                c = source[i]
                if (source[i] == '\r' || source[i] == '\n') continue
            }
            when {
                c == ' ' || c == '\t' -> {
                    val start = i
                    while (i < source.length && (source[i] == ' ' || source[i] == '\t')) i++
                    add(TokenType.WHITESPACE, start, i)
                }
                c == '#' -> {
                    val start = i
                    while (i < source.length && source[i] != '\r' && source[i] != '\n') i++
                    add(TokenType.COMMENT, start, i)
                }
                c == '\'' || c == '"' -> {
                    val start = i
                    val q = c
                    val triple = i + 2 < source.length && source[i + 1] == q && source[i + 2] == q
                    i += if (triple) 3 else 1
                    var escaped = false
                    var closed = false
                    while (i < source.length) {
                        val ch = source[i]
                        if (escaped) { escaped = false; i++ }
                        else if (ch == '\\') { escaped = true; i++ }
                        else if (triple && ch == q && i + 2 < source.length && source[i + 1] == q && source[i + 2] == q) {
                            i += 3; closed = true; break
                        } else if (!triple && ch == q) { i++; closed = true; break }
                        else if (!triple && (ch == '\r' || ch == '\n')) break
                        else i++
                    }
                    add(if (closed) TokenType.STRING else TokenType.BAD_CHARACTER, start, i)
                }
                c.isLetter() || c == '_' -> {
                    val start = i++
                    while (i < source.length && (source[i].isLetterOrDigit() || source[i] == '_')) i++
                    val word = source.subSequence(start, i).toString()
                    add(if (word in keywords) TokenType.KEYWORD else TokenType.IDENTIFIER, start, i)
                }
                c.isDigit() -> {
                    val start = i++
                    while (i < source.length && (source[i].isDigit() || source[i] == '.')) i++
                    add(TokenType.NUMBER, start, i)
                }
                c in "()[]{}:,.;" -> { add(TokenType.PUNCTUATION, i, i + 1); i++ }
                c in "+-*/%=<>!&|~^" -> {
                    val start = i++
                    while (i < source.length && source[i] in "+-*/%=<>!&|~^") i++
                    add(TokenType.OPERATOR, start, i)
                }
                else -> { add(TokenType.BAD_CHARACTER, i, i + 1); i++ }
            }
        }
        while (indentStack.size > 1) {
            indentStack.removeLast()
            tokens += RenPyToken(TokenType.DEDENT, source.length, source.length, "")
        }
        tokens += RenPyToken(TokenType.EOF, source.length, source.length, "")
        return tokens
    }

    companion object {
        val DEFAULT_KEYWORDS = setOf(
            "label", "init", "define", "default", "image", "scene", "show", "hide",
            "play", "queue", "stop", "menu", "if", "elif", "else", "while", "python",
            "call", "from", "jump", "return", "pause", "with", "at", "as", "onlayer",
            "behind", "screen", "transform", "style", "layer", "camera", "window"
        )
    }
}
