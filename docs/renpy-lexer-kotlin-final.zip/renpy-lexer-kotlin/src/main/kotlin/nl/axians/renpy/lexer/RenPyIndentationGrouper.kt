package nl.axians.renpy.lexer

import nl.axians.renpy.lexer.model.*
import java.util.ArrayDeque

class RenPyIndentationGrouper {
    fun group(lines: List<LogicalLine>, sourceLength: Int = lines.lastOrNull()?.endOffset ?: 0): IndentationResult {
        val events = mutableListOf<IndentationEvent>()
        val diagnostics = mutableListOf<LexicalDiagnostic>()
        val levels = ArrayDeque<Int>()
        levels.addLast(0)
        for (line in lines) {
            when {
                line.indent > levels.last() -> {
                    levels.addLast(line.indent)
                    events += IndentationEvent(IndentationType.INDENT, line.startOffset, line.startLine)
                }
                line.indent < levels.last() -> {
                    while (levels.size > 1 && line.indent < levels.last()) {
                        levels.removeLast()
                        events += IndentationEvent(IndentationType.DEDENT, line.startOffset, line.startLine)
                    }
                    if (levels.last() != line.indent) {
                        diagnostics += LexicalDiagnostic(DiagnosticCode.INCONSISTENT_INDENTATION, "Indentation does not match an outer level.", line.startOffset, line.startLine)
                        levels.addLast(line.indent)
                        events += IndentationEvent(IndentationType.INDENT, line.startOffset, line.startLine)
                    }
                }
            }
        }
        val eofLine = lines.lastOrNull()?.endLine ?: 1
        while (levels.size > 1) {
            levels.removeLast()
            events += IndentationEvent(IndentationType.DEDENT, sourceLength, eofLine)
        }
        return IndentationResult(events, diagnostics)
    }
}
