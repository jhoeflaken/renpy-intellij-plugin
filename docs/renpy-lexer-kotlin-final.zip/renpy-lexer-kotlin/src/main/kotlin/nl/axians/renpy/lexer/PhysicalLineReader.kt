package nl.axians.renpy.lexer

import nl.axians.renpy.lexer.model.PhysicalLine

object PhysicalLineReader {
    fun read(source: CharSequence): List<PhysicalLine> {
        val result = mutableListOf<PhysicalLine>()
        var start = 0
        var line = 1
        var i = 0
        while (i < source.length) {
            if (source[i] == '\r' || source[i] == '\n') {
                val contentEnd = i
                if (source[i] == '\r' && i + 1 < source.length && source[i + 1] == '\n') i += 2 else i++
                result += PhysicalLine(line, start, contentEnd, i, source.subSequence(start, contentEnd).toString())
                start = i
                line++
            } else i++
        }
        if (start < source.length) result += PhysicalLine(line, start, source.length, source.length, source.subSequence(start, source.length).toString())
        return result
    }
}
