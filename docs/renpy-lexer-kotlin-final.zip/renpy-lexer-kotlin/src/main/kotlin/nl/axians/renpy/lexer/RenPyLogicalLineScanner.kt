package nl.axians.renpy.lexer

import nl.axians.renpy.lexer.model.*
import java.util.ArrayDeque

/** Groups physical lines into logical statements while preserving original source offsets. */
class RenPyLogicalLineScanner {
    fun scan(source: CharSequence): LogicalScanResult {
        val physical = PhysicalLineReader.read(source)
        val output = mutableListOf<LogicalLine>()
        val diagnostics = mutableListOf<LexicalDiagnostic>()
        var active = false
        var startOffset = 0
        var startLine = 1
        var indent = 0
        var segments = mutableListOf<TextRange>()
        val text = StringBuilder()
        val delimiters = ArrayDeque<Pair<Char, Pair<Int, Int>>>()
        var quote: Char? = null
        var triple = false
        var escaped = false
        var stringOffset = -1
        var stringLine = -1

        fun finish(end: Int, endLine: Int) {
            if (!active) return
            output += LogicalLine(startLine, endLine, startOffset, end, indent, segments.toList(), text.toString())
            active = false
            segments = mutableListOf()
            text.setLength(0)
        }

        for (line in physical) {
            val s = line.text
            var i = 0
            if (!active && quote == null && delimiters.isEmpty()) {
                var p = 0
                var columns = 0
                while (p < s.length && (s[p] == ' ' || s[p] == '\t')) {
                    if (s[p] == '\t') {
                        diagnostics += LexicalDiagnostic(DiagnosticCode.TAB_INDENTATION, "Tab in indentation.", line.startOffset + p, line.lineNumber)
                        columns = (columns / 8 + 1) * 8
                    } else columns++
                    p++
                }
                if (p == s.length || s[p] == '#') continue
                active = true
                startOffset = line.startOffset + p
                startLine = line.lineNumber
                indent = columns
                i = p
            } else if (!active) {
                active = true
                startOffset = line.startOffset
                startLine = line.lineNumber
                indent = 0
            }

            val segmentStart = i
            var commentAt: Int? = null
            while (i < s.length) {
                val c = s[i]
                val absolute = line.startOffset + i
                if (quote != null) {
                    if (escaped) { escaped = false; i++; continue }
                    if (c == '\\') { escaped = true; i++; continue }
                    if (triple && c == quote && i + 2 < s.length && s[i + 1] == quote && s[i + 2] == quote) {
                        quote = null; triple = false; i += 3; continue
                    }
                    if (!triple && c == quote) { quote = null; i++; continue }
                    i++; continue
                }
                when {
                    c == '#' -> { commentAt = i; break }
                    c == '\'' || c == '"' -> {
                        quote = c; stringOffset = absolute; stringLine = line.lineNumber
                        triple = i + 2 < s.length && s[i + 1] == c && s[i + 2] == c
                        i += if (triple) 3 else 1
                    }
                    c == '(' || c == '[' || c == '{' -> { delimiters.addLast(c to (absolute to line.lineNumber)); i++ }
                    c == ')' || c == ']' || c == '}' -> {
                        val expected = when (c) { ')' -> '('; ']' -> '['; else -> '{' }
                        if (delimiters.lastOrNull()?.first == expected) delimiters.removeLast()
                        else diagnostics += LexicalDiagnostic(DiagnosticCode.UNMATCHED_CLOSING_DELIMITER, "Unmatched closing delimiter '$c'.", absolute, line.lineNumber)
                        i++
                    }
                    else -> i++
                }
            }

            val endInLine = commentAt ?: s.length
            if (endInLine > segmentStart) {
                val a = line.startOffset + segmentStart
                val b = line.startOffset + endInLine
                segments += TextRange(a, b)
                if (text.isNotEmpty()) text.append('\n')
                text.append(s.substring(segmentStart, endInLine))
            }

            var last = endInLine - 1
            while (last >= segmentStart && (s[last] == ' ' || s[last] == '\t')) last--
            val continuation = quote == null && commentAt == null && last >= segmentStart &&
                s[last] == '\\' && isUnescapedBackslash(s, last)
            if (continuation && segments.isNotEmpty()) {
                segments[segments.lastIndex] = segments.last().copy(endOffset = line.startOffset + last)
                if (text.isNotEmpty() && text.last() == '\\') text.setLength(text.length - 1)
            }

            if (quote == null && delimiters.isEmpty() && !continuation) finish(line.contentEndOffset, line.lineNumber)
        }

        if (quote != null) diagnostics += LexicalDiagnostic(DiagnosticCode.UNCLOSED_STRING, "Unterminated string.", stringOffset, stringLine)
        if (delimiters.isNotEmpty()) {
            val (d, pos) = delimiters.last()
            diagnostics += LexicalDiagnostic(DiagnosticCode.UNCLOSED_DELIMITER, "Unclosed delimiter '$d'.", pos.first, pos.second)
        }
        if (active) finish(source.length, physical.lastOrNull()?.lineNumber ?: 1)
        return LogicalScanResult(output, diagnostics, source.length)
    }

    private fun isUnescapedBackslash(s: String, index: Int): Boolean {
        var count = 0
        var i = index
        while (i >= 0 && s[i] == '\\') { count++; i-- }
        return count % 2 == 1
    }
}
